studentFile = open("DXC5-StudFile2.txt", "r")

choice = "Y"
counter = 0

for studentRecord in studentFile:
    fieldSplit = studentRecord.split(",")
    totMarks = int(fieldSplit[2]) + int(fieldSplit[3]) + int(fieldSplit[4])
    avgMarks = totMarks / 3

    print("Result of Student : " + fieldSplit[1] + " having Roll No : " + fieldSplit[0])
    print("Physics Marks : " + fieldSplit[2])
    print("Chemistry Marks : " + fieldSplit[3])
    print("Mathematics Marks : " + fieldSplit[4])

    print("Total Marks : ", totMarks)
    print("Average Marks : ", avgMarks )
    counter = counter + 1

    choice = input("Do you want to See Result for  another student (Y/N) : ")

studentFile.close()
print("No of Result Viewed : ", counter)



